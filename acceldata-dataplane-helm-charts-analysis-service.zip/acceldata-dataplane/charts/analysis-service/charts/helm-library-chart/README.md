## FIND SAMPLE TEMPLATE HERE https://bitbucket.org/acceldata/helm-library-chart/src/master/sample/ 

## Deployment

| Section                   | Field Name                                          | Default Value           | Required | Example                                                                                                     |
|---------------------------|-----------------------------------------------------|-------------------------|----------|-------------------------------------------------------------------------------------------------------------|
| **Deployment**            | `fullnameOverride`                                  | None                    | No       | `fullnameOverride: custom-name`                                                                             |
|                           | `Deployment.namespace`                              | `.Release.namespace`    | No       | `Deployment: { namespace: custom-namespace }`                                                              |
|                           | `Deployment.replicas`                               | `2`                     | No       | `Deployment: { replicas: 3 }`                                                                               |
|                           | `Deployment.strategy.type`                          | `RollingUpdate`         | No       | `Deployment: { strategy: { type: Recreate } }`                                                              |
|                           | `Deployment.strategy.rollingUpdate.maxSurge`        | `1`                     | No       | `Deployment: { strategy: { rollingUpdate: { maxSurge: 2 } } }`                                              |
|                           | `Deployment.strategy.rollingUpdate.maxUnavailable`  | `1`                     | No       | `Deployment: { strategy: { rollingUpdate: { maxUnavailable: 0 } } }`                                        |
|                           | `Deployment.dnsPolicy`                              | `ClusterFirst`          | No       | `Deployment: { dnsPolicy: Default }`                                                                        |
|                           | `Deployment.dnsConfig.nameservers`                  | None                    | No       | `Deployment: { dnsConfig: { nameservers: ["1.1.1.1"] } }`                                                    |
|                           | `Deployment.dnsConfig.searches`                     | None                    | No       | `Deployment: { dnsConfig: { searches: ["mydomain.local"] } }`                                                |
|                           | `Deployment.dnsConfig.options`                      | None                    | No       | `Deployment: { dnsConfig: { options: [{name: "ndots", value: "2"}] } }`                                     |
|                           | `Deployment.affinity.podAffinity`                   | None                    | No       | `Deployment: { affinity: { podAffinity: {...} } }`                                                           |
|                           | `Deployment.affinity.podAntiAffinity`               | None                    | No       | `Deployment: { affinity: { podAntiAffinity: {...} } }`                                                       |
|                           | `Deployment.affinity.nodeAffinity`                  | None                    | No       | `Deployment: { affinity: { nodeAffinity: {...} } }`                                                          |
|                           | `Deployment.hostAliases`                            | None                    | No       | `Deployment: { hostAliases: [{ ip: "127.0.0.1", hostnames: ["example.com"] }] }`                             |
|                           | `Deployment.imagePullSecrets`                       | None                    | No       | `Deployment: { imagePullSecrets: [{ name: "mysecret" }] }`                                                   |
|                           | `Deployment.nodeSelector`                           | None                    | No       | `Deployment: { nodeSelector: { "disktype": "ssd" } }`                                                        |
|                           | `Deployment.overhead`                               | None                    | No       | `Deployment: { overhead: { "cpu": "100m", "memory": "200Mi" } }`                                             |
|                           | `Deployment.readinessGates`                         | None                    | No       | `Deployment: { readinessGates: [{ conditionType: "Ready" }] }`                                               |
|                           | `Deployment.securityContext`                        | None                    | No       | `Deployment: { securityContext: { runAsUser: 1000 } }`                                                       |
|                           | `Deployment.tolerations`                            | None                    | No       | `Deployment: { tolerations: [{ key: "key1", operator: "Exists", effect: "NoSchedule" }] }`                  |
|                           | `Deployment.topologySpreadConstraints`              | None                    | No       | `Deployment: { topologySpreadConstraints: [{ maxSkew: 1, topologyKey: "kubernetes.io/hostname", whenUnsatisfiable: "ScheduleAnyway", labelSelector: { matchLabels: { "app": "myapp" } } }] }` |
|                           | `Deployment.activeDeadlineSeconds`                  | None                    | No       | `Deployment: { activeDeadlineSeconds: 3600 }`                                                                |
|                           | `Deployment.automountServiceAccountToken`           | None                    | No       | `Deployment: { automountServiceAccountToken: false }`                                                        |
|                           | `Deployment.enableServiceLinks`                     | None                    | No       | `Deployment: { enableServiceLinks: false }`                                                                  |
|                           | `Deployment.hostIPC`                                | None                    | No       | `Deployment: { hostIPC: true }`                                                                              |
|                           | `Deployment.hostNetwork`                            | None                    | No       | `Deployment: { hostNetwork: true }`                                                                          |
|                           | `Deployment.hostUsers`                              | None                    | No       | `Deployment: { hostUsers: true }`                                                                            |
|                           | `Deployment.hostname`                               | None                    | No       | `Deployment: { hostname: "custom-hostname" }`                                                                |
|                           | `Deployment.nodeName`                               | None                    | No       | `Deployment: { nodeName: "specific-node" }`                                                                  |
|                           | `Deployment.os.name`                                | None                    | No       | `Deployment: { os: { name: "Linux" } }`                                                                      |
|                           | `Deployment.preemptionPolicy`                       | None                    | No       | `Deployment: { preemptionPolicy: "PreemptLowerPriority" }`                                                   |
|                           | `Deployment.priority`                               | None                    | No       | `Deployment: { priority: 1000 }`                                                                             |
|                           | `Deployment.priorityClassName`                      | None                    | No       | `Deployment: { priorityClassName: "high-priority" }`                                                         |
|                           | `Deployment.restartPolicy`                          | None                    | No       | `Deployment: { restartPolicy: "Always" }`                                                                    |
|                           | `Deployment.runtimeClassName`                       | None                    | No       | `Deployment: { runtimeClassName: "custom-runtime" }`                                                         |
|                           | `Deployment.schedulerName`                          | None                    | No       | `Deployment: { schedulerName: "custom-scheduler" }`                                                          |
|                           | `Deployment.serviceAccount`                         | None                    | No       | `Deployment: { serviceAccount: "custom-service-account" }`                                                   |
|                           | `Deployment.serviceAccountName`                     | None                    | No       | `Deployment: { serviceAccountName: "custom-service-account-name" }`                                          |
|                           | `Deployment.setHostnameAsFQDN`                      | None                    | No       | `Deployment: { setHostnameAsFQDN: true }`                                                                    |
|                           | `Deployment.shareProcessNamespace`                  | None                    | No       | `Deployment: { shareProcessNamespace: true }`                                                                |
|                           | `Deployment.subdomain`                              | None                    | No       | `Deployment: { subdomain: "subdomain-name" }`                                                                |
|                           | `Deployment.terminationGracePeriodSeconds`          | None                    | No       | `Deployment: { terminationGracePeriodSeconds: 30 }`                                                          |
|                           | `Deployment.volumes`                                | None                    | No       |                                                                                                              |
| **Init Containers**       | `Deployment.initContainers[]`                       | None                    | No       |                                                                                                              |
| **Ephemeral Containers**  | `Deployment.ephemeralContainers[]`                  | None                    | No       |                                                                                                              |
| **Primary Containers**    | `Deployment.containers[]`                           | None                    | Yes      | `                                                                                                            |


## Containers

| Field Name                                     | Default Value              | Required | Example                                                                                     |
|------------------------------------------------|----------------------------|----------|---------------------------------------------------------------------------------------------|
| `containers[].name`                            | None                       | Yes      | `containers: [{ name: "app-container" }]`                                                   |
| `containers[].image`                           | None                       | Yes      | `containers: [{ name: "app-container", image: "nginx:latest" }]`                            |
| `containers[].imagePullPolicy`                 | None                       | No       | `containers: [{ name: "app-container", imagePullPolicy: "Always" }]`                        |
| `containers[].ports`                           | None                       | No       | `containers: [{ ports: [{ containerPort: 80, protocol: "TCP" }] }]`                         |
| `containers[].env`                             | None                       | No       | `containers: [{ env: [{ name: "ENV_VAR", value: "value" }] }]`                              |
| `containers[].envFrom`                         | None                       | No       | `containers: [{ envFrom: [{ configMapRef: { name: "configmap-name" } }] }]`                 |
| `containers[].args`                            | None                       | No       | `containers: [{ args: ["-c", "printenv"] }]`                                                |
| `containers[].command`                         | None                       | No       | `containers: [{ command: ["/bin/bash", "-c", "echo Hello World"] }]`                        |
| `containers[].lifecycle`                       | None                       | No       | `containers: [{ lifecycle: { postStart: { exec: { command: ["/bin/sh", "-c", "echo Hello"] } } }] }` |
| `containers[].livenessProbe`                   | None                       | No       | `containers: [{ livenessProbe: { httpGet: { path: "/", port: 80 } } }]`                     |
| `containers[].readinessProbe`                  | None                       | No       | `containers: [{ readinessProbe: { httpGet: { path: "/ready", port: 80 } } }]`               |
| `containers[].resources`                       | None                       | No       | `containers: [{ resources: { limits: { cpu: "100m", memory: "200Mi" }, requests: { cpu: "100m", memory: "200Mi" } } }]` |
| `containers[].securityContext`                 | None                       | No       | `containers: [{ securityContext: { runAsUser: 1000 } }]`                                    |
| `containers[].startupProbe`                    | None                       | No       | `containers: [{ startupProbe: { httpGet: { path: "/start", port: 80 } } }]`                 |
| `containers[].stdin`                           | `false`                    | No       | `containers: [{ stdin: true }]`                                                             |
| `containers[].stdinOnce`                       | `false`                    | No       | `containers: [{ stdinOnce: true }]`                                                         |
| `containers[].terminationMessagePath`          | "/dev/termination-log"     | No       | `containers: [{ terminationMessagePath: "/custom/path" }]`                                  |
| `containers[].terminationMessagePolicy`        | "File"                     | No       | `containers: [{ terminationMessagePolicy: "FallbackToLogsOnError" }]`                       |
| `containers[].tty`                             | `false`                    | No       | `containers: [{ tty: true }]`                                                               |
| `containers[].volumeMounts`                    | None                       | No       | `containers: [{ volumeMounts: [{ name: "my-volume", mountPath: "/data" }] }]`               |
| `containers[].volumeDevices`                   | None                       | No       | `containers: [{ volumeDevices: [{ name: "my-volume", devicePath: "/dev/xvda" }] }]`         |
| `containers[].workingDir`                      | None                       | No       | `containers: [{ workingDir: "/app" }]`                                                      |

## Cronjob

| Field Name                                                   | Default Value | Required | Example                                           |
|--------------------------------------------------------------|---------------|----------|---------------------------------------------------|
| `fullnameOverride`                                           | `nil`         | No       | `fullnameOverride: my-custom-name`                |
| `Release.Name`                                               | Provided by Helm at runtime | Yes | N/A                                           |
| `Chart.Name`                                                 | Provided by Helm at runtime | Yes | N/A                                           |
| `CronJob.namespace`                                          | `nil`         | No       | `namespace: my-namespace`                         |
| `CronJob.schedule`                                           | `nil`         | Yes      | `schedule: "*/5 * * * *"`                         |
| `CronJob.startingDeadlineSeconds`                            | `nil`         | No       | `startingDeadlineSeconds: 200`                    |
| `CronJob.concurrencyPolicy`                                  | `nil`         | No       | `concurrencyPolicy: Replace`                      |
| `CronJob.suspend`                                            | `nil`         | No       | `suspend: false`                                  |
| `CronJob.successfulJobsHistoryLimit`                         | `nil`         | No       | `successfulJobsHistoryLimit: 3`                   |
| `CronJob.failedJobsHistoryLimit`                             | `nil`         | No       | `failedJobsHistoryLimit: 1`                       |
| `CronJob.timeZone`                                           | `nil`         | No       | `timeZone: "America/New_York"`                    |
| `CronJob.jobTemplate.spec.activeDeadlineSeconds`             | `nil`         | No       | `activeDeadlineSeconds: 100`                      |
| `CronJob.jobTemplate.spec.backoffLimit`                      | `nil`         | No       | `backoffLimit: 6`                                 |
| `CronJob.jobTemplate.spec.completionMode`                    | `nil`         | No       | `completionMode: NonIndexed`                      |
| `CronJob.jobTemplate.spec.completions`                       | `nil`         | No       | `completions: 1`                                  |
| `CronJob.jobTemplate.spec.manualSelector`                    | `nil`         | No       | `manualSelector: false`                           |
| `CronJob.jobTemplate.spec.parallelism`                       | `nil`         | No       | `parallelism: 1`                                  |
| `CronJob.jobTemplate.spec.ttlSecondsAfterFinished`           | `nil`         | No       | `ttlSecondsAfterFinished: 3600`                   |
| `CronJob.jobTemplate.spec.template.spec.activeDeadlineSeconds` | `nil`       | No       | `activeDeadlineSeconds: 100`                      |
| `CronJob.jobTemplate.spec.template.spec.affinity`            | `nil`         | No       | `affinity: {nodeAffinity: {}}`                    |
| `CronJob.jobTemplate.spec.template.spec.automountServiceAccountToken` | `nil` | No | `automountServiceAccountToken: true`             |
| `CronJob.jobTemplate.spec.template.spec.dnsPolicy`           | `ClusterFirst`| No       | `dnsPolicy: Default`                              |
| `CronJob.jobTemplate.spec.template.spec.dnsConfig`           | `nil`         | No       | `dnsConfig: {nameservers: ["8.8.8.8"]}`           |
| `CronJob.jobTemplate.spec.template.spec.enableServiceLinks`  | `nil`         | No       | `enableServiceLinks: true`                        |
| `CronJob.jobTemplate.spec.template.spec.ephemeralContainers` | `nil`         | No       | `ephemeralContainers: [{name: "debug-container"}]`|
| `CronJob.jobTemplate.spec.template.spec.hostAliases`         | `nil`         | No       | `hostAliases: [{ip: "127.0.0.1", hostnames: ["localhost"]}]` |
| `CronJob.jobTemplate.spec.template.spec.hostIPC`             | `nil`         | No       | `hostIPC: false`                                  |
| `CronJob.jobTemplate.spec.template.spec.hostNetwork`         | `nil`         | No       | `hostNetwork: false`                              |
| `CronJob.jobTemplate.spec.template.spec.hostPID`             | `nil`         | No       | `hostPID: false`                                  |
| `CronJob.jobTemplate.spec.template.spec.hostname`            | `nil`         | No       | `hostname: my-hostname`                           |
| `CronJob.jobTemplate.spec.template.spec.imagePullSecrets`    | `nil`         | No       | `imagePullSecrets: [{name: "my-secret"}]`         |
| `CronJob.jobTemplate.spec.template.spec.initContainers`      | `nil`         | No       | `initContainers: [{name: "init-mydb"}]`           |
| `CronJob.jobTemplate.spec.template.spec.nodeName`            | `nil`         | No       | `nodeName: "my-node"`                             |
| `CronJob.jobTemplate.spec.template.spec.nodeSelector`        | `nil`         | No       | `nodeSelector: {disktype: ssd}`                   |
| `CronJob.jobTemplate.spec.template.spec.overhead`            | `nil`         | No       | `overhead: {memory: "100Mi"}`                     |
| `CronJob.jobTemplate.spec.template.spec.preemptionPolicy`    | `nil`         | No       | `preemptionPolicy: PreemptLowerPriority`          |
| `CronJob.jobTemplate.spec.template.spec.priority`            | `nil`         | No       | `priority: 1000`                                  |
| `CronJob.jobTemplate.spec.template.spec.priorityClassName`   | `nil`         | No       | `priorityClassName: high-priority`                |
| `CronJob.jobTemplate.spec.template.spec.readinessGates`      | `nil`         | No       | `readinessGates: [{conditionType: "Ready"}]`      |
| `CronJob.jobTemplate.spec.template.spec.restartPolicy`       | `nil`         | No       | `restartPolicy: Always`                           |
| `CronJob.jobTemplate.spec.template.spec.runtimeClassName`    | `nil`         | No       | `runtimeClassName: my-runtime-class`              |
| `CronJob.jobTemplate.spec.template.spec.schedulerName`       | `nil`         | No       | `schedulerName: my-scheduler`                     |
| `CronJob.jobTemplate.spec.template.spec.securityContext`     | `nil`         | No       | `securityContext: {runAsUser: 1000}`              |
| `CronJob.jobTemplate.spec.template.spec.serviceAccount`      | `nil`         | No       | `serviceAccount: my-service-account`              |
| `CronJob.jobTemplate.spec.template.spec.serviceAccountName`  | `nil`         | No       | `serviceAccountName: my-service-account-name`     |
| `CronJob.jobTemplate.spec.template.spec.shareProcessNamespace` | `nil`       | No       | `shareProcessNamespace: true`                     |
| `CronJob.jobTemplate.spec.template.spec.subdomain`           | `nil`         | No       | `subdomain: my-subdomain`                         |
| `CronJob.jobTemplate.spec.template.spec.terminationGracePeriodSeconds` | `nil` | No | `terminationGracePeriodSeconds: 30`           |
| `CronJob.jobTemplate.spec.template.spec.tolerations`         | `nil`         | No       | `tolerations: [{key: "key1", operator: "Exists", effect: "NoSchedule"}]` |
| `CronJob.jobTemplate.spec.template.spec.topologySpreadConstraints` | `nil` | No | `topologySpreadConstraints: [{maxSkew: 1, topologyKey: "topology.kubernetes.io/zone", whenUnsatisfiable: "ScheduleAnyway"}]` |
| `CronJob.jobTemplate.spec.template.spec.volumes`             | `nil`         | No       | `volumes: [{name: "my-volume", emptyDir: {}}]`    |

## Horizontal Pod Autoscaler

| Field Name                                            | Default Value                          | Required | Example                                                      |
|-------------------------------------------------------|----------------------------------------|----------|--------------------------------------------------------------|
| `fullnameOverride`                                    | `nil`                                  | No       | `fullnameOverride: my-custom-hpa`                             |
| `Release.Name`                                        | Provided by Helm at runtime            | Yes      | N/A                                                          |
| `Chart.Name`                                          | Provided by Helm at runtime            | Yes      | N/A                                                          |
| `HorizontalPodAutoscaler.namespace`                   | `.Release.namespace`                   | No       | `namespace: my-namespace`                                    |
| `HorizontalPodAutoscaler.scaleTargetRef.apiVersion`   | `apps/v1`                              | No       | `scaleTargetRef.apiVersion: apps/v1`                         |
| `HorizontalPodAutoscaler.scaleTargetRef.kind`         | `Deployment`                           | No       | `scaleTargetRef.kind: Deployment`                            |
| `HorizontalPodAutoscaler.scaleTargetRef.name`         | Derived from `fullnameOverride` or `Release.Name` | Yes | `scaleTargetRef.name: my-deployment-name`                 |
| `HorizontalPodAutoscaler.minReplicas`                 | `1`                                    | No       | `minReplicas: 1`                                             |
| `HorizontalPodAutoscaler.maxReplicas`                 | `4`                                    | No       | `maxReplicas: 5`                                             |
| `HorizontalPodAutoscaler.metrics`                     | Default metrics configuration          | No       | `metrics: [{type: Resource, resource: {name: cpu, target: {type: Utilization, averageUtilization: 80}}}]` |
| `HorizontalPodAutoscaler.behavior`                    | `nil`                                  | No       | `behavior: {scaleDown: {stabilizationWindowSeconds: 300, policies: [{type: Pods, value: 1, periodSeconds: 60}]}}` |
| `HorizontalPodAutoscaler.labels`                      | Merged from `.Values.HorizontalPodAutoscaler` | No | `labels: {app: my-app}`                                   |
| `HorizontalPodAutoscaler.annotations`                 | Merged from `.Values.HorizontalPodAutoscaler` | No | `annotations: {note: "Managed by Helm"}`                  |

## Persistent Volume

| Field Name                                        | Default Value  | Required | Example                                           |
|---------------------------------------------------|----------------|----------|---------------------------------------------------|
| `fullnameOverride`                                | `nil`          | No       | `fullnameOverride: custom-pv`                     |
| `Release.Name`                                    | Set by Helm    | Yes      | N/A                                               |
| `Chart.Name`                                      | Set by Helm    | Yes      | N/A                                               |
| `PersistentVolume.namespace`                      | `.Release.namespace` | No | `namespace: my-namespace`                       |
| `PersistentVolume.accessModes`                    | `["ReadWriteOnce"]` | No | `accessModes: ["ReadWriteOnce", "ReadOnlyMany"]` |
| `PersistentVolume.awsElasticBlockStore`           | `nil`          | No       | `awsElasticBlockStore: {volumeID: "vol-0a89...}`  |
| `PersistentVolume.azureDisk`                      | `nil`          | No       | `azureDisk: {diskName: "mydisk",...}`             |
| `PersistentVolume.capacity`                       | `nil`          | No       | `capacity: {storage: "10Gi"}`                     |
| `PersistentVolume.cephfs`                         | `nil`          | No       | `cephfs: {monitors: ["192.168.0.1:6789"],...}`    |
| `PersistentVolume.cinder`                         | `nil`          | No       | `cinder: {volumeID: "abc123",...}`                |
| `PersistentVolume.claimRef`                       | `nil`          | No       | `claimRef: {namespace: "default", name: "myclaim"}` |
| `PersistentVolume.csi`                            | `nil`          | No       | `csi: {driver: "csi-driver",...}`                 |
| `PersistentVolume.fc`                             | `nil`          | No       | `fc: {targetWWNs: ["500a098..."],...}`            |
| `PersistentVolume.flexVolume`                     | `nil`          | No       | `flexVolume: {driver: "flex-driver",...}`         |
| `PersistentVolume.flocker`                        | `nil`          | No       | `flocker: {datasetUUID: "dataset-uuid"}`          |
| `PersistentVolume.gcePersistentDisk`              | `nil`          | No       | `gcePersistentDisk: {pdName: "my-disk",...}`      |
| `PersistentVolume.glusterfs`                      | `nil`          | No       | `glusterfs: {endpoints: "glusterfs-cluster",...}` |
| `PersistentVolume.hostPath`                       | `nil`          | No       | `hostPath: {path: "/data", type: "Directory"}`    |
| `PersistentVolume.iscsi`                          | `nil`          | No       | `iscsi: {targetPortal: "10.0.0.1:3260",...}`      |
| `PersistentVolume.local`                          | `nil`          | No       | `local: {path: "/mnt/disks/ssd1"}`                |
| `PersistentVolume.mountOptions`                   | `nil`          | No       | `mountOptions: ["hard", "nfsvers=4.1"]`           |
| `PersistentVolume.nfs`                            | `nil`          | No       | `nfs: {path: "/usr/local", server: "192.168.0.1"}`|
| `PersistentVolume.PersistentVolumeReclaimPolicy` | `nil`          | No       | `PersistentVolumeReclaimPolicy: "Retain"`         |
| `PersistentVolume.photonPersistentDisk`           | `nil`          | No       | `photonPersistentDisk: {pdID: "photon-disk-id"}`  |
| `PersistentVolume.portworxVolume`                 | `nil`          | No       | `portworxVolume: {volumeID: "pxvol"}`             |
| `PersistentVolume.quobyte`                        | `nil`          | No       | `quobyte: {registry: "192.168.100.1:7861",...}`   |
| `PersistentVolume.rbd`                            | `nil`          | No       | `rbd: {monitors: ["192.168.0.10"],...}`           |
| `PersistentVolume.scaleIO`                        | `nil`          | No       | `scaleIO: {gateway: "https://scaleio-gw",...}`    |
| `PersistentVolume.storageClassName`               | `nil`          | No       | `storageClassName: "standard"`                    |
| `PersistentVolume.storageos`                      | `nil`          | No       | `storageos: {volumeName: "vol01",...}`            |
| `PersistentVolume.volumeMode`                     | `nil`          | No       | `volumeMode: "Filesystem"`                        |
| `PersistentVolume.vsphereVolume`                  | `nil`          | No       | `vsphereVolume: {volumePath: "[datastore1] vol/vm",...}` |



## Persistent Volume Claim

| Field Name                                       | Default Value          | Required | Example                                                    |
|--------------------------------------------------|------------------------|----------|------------------------------------------------------------|
| `fullnameOverride`                               | `nil`                  | No       | `fullnameOverride: custom-pvc`                             |
| `Release.Name`                                   | Provided by Helm at runtime | Yes | N/A                                                        |
| `Chart.Name`                                     | Provided by Helm at runtime | Yes | N/A                                                        |
| `PersistentVolumeClaim.namespace`                | `.Release.namespace`   | No       | `namespace: my-namespace`                                  |
| `PersistentVolumeClaim.accessModes`              | `["ReadWriteOnce"]`    | No       | `accessModes: ["ReadWriteOnce", "ReadOnlyMany"]`           |
| `PersistentVolumeClaim.resources.limits`         | `nil`                  | No       | `resources: { limits: { cpu: "500m", memory: "1Gi" } }`    |
| `PersistentVolumeClaim.resources.requests`       | `nil`                  | No       | `resources: { requests: { cpu: "200m", memory: "500Mi" } }`|
| `PersistentVolumeClaim.storageClassName`         | `nil`                  | No       | `storageClassName: "standard"`                             |
| `PersistentVolumeClaim.selector`                 | `nil`                  | No       | `selector: { matchLabels: { app: "my-app" } }`             |
| `PersistentVolumeClaim.volumeMode`               | `nil`                  | No       | `volumeMode: "Filesystem"`                                 |
| `PersistentVolumeClaim.volumeName`               | `nil`                  | No       | `volumeName: "my-volume"`                                  |
| `PersistentVolumeClaim.dataSource`               | `nil`                  | No       | `dataSource: { apiGroup: "", kind: "PersistentVolumeClaim", name: "data-pvc" }` |
| `PersistentVolumeClaim.dataSourceRef`            | `nil`                  | No       | `dataSourceRef: { apiGroup: "", kind: "Snapshot", name: "snapshot-pvc" }` |


## Rbac

| Field Name                                    | Default Value        | Required | Example                                                      |
|-----------------------------------------------|----------------------|----------|--------------------------------------------------------------|
| `Rbac.clusterWideAccess`                      | `false`              | No       | `clusterWideAccess: true`                                    |
| `kind`                                        | Role or ClusterRole  | Yes      | Determined by `Rbac.clusterWideAccess`                       |
| `apiVersion`                                  | `rbac.authorization.k8s.io/v1` | Yes | `apiVersion: rbac.authorization.k8s.io/v1`                  |
| `metadata.name`                               | Computed name        | Yes      | `name: my-custom-name`                                       |
| `metadata.labels`                             | Computed labels      | No       | `labels: {app: myapp, release: myrelease}`                   |
| `metadata.annotations`                        | Computed annotations | No       | `annotations: {example: "This is an annotation"}`            |
| `metadata.namespace`                          | `.Release.namespace` | No       | `namespace: custom-namespace`                                |
| `Rbac.aggregationRule`                        | None                 | No       | `aggregationRule: { clusterRoleSelectors: [{matchLabels: {role: myrole}}] }` |
| `Rbac.rules`                                  | None                 | Yes      | See rules examples below                                     |
| `rules[].nonResourceURLs`                     | None                 | No       | `nonResourceURLs: ["/health", "/api"]`                       |
| `rules[].apiGroups`                           | `*`                  | No       | `apiGroups: ["", "v1"]`                                      |
| `rules[].resources`                           | `*`                  | No       | `resources: ["pods", "services"]`                            |
| `rules[].verbs`                               | `*`                  | No       | `verbs: ["get", "list"]`                                     |
| `rules[].resourceNames`                       | None                 | No       | `resourceNames: ["myresource"]`                              |

### Rules Field Details

- **`nonResourceURLs`**: Specifies access to non-resource endpoints (paths).
- **`apiGroups`**: Specifies the API groups that this rule applies to. `"*"` applies to all API groups.
- **`resources`**: Specifies the resources within the API group to which the rule applies. `"*"` applies to all resources.
- **`verbs`**: Specifies the verbs that this rule will allow. `"*"` allows all verbs.
- **`resourceNames`**: Specifies the names of resources that the rule applies to within the given API group.

## Rbac Binding

| Field Name                             | Default Value                  | Required | Example                                                       |
|----------------------------------------|--------------------------------|----------|---------------------------------------------------------------|
| `RbacBinding.clusterWideAccess`        | `false`                        | No       | `clusterWideAccess: true`                                     |
| `kind`                                 | RoleBinding or ClusterRoleBinding | Yes   | Automatically determined by `clusterWideAccess`               |
| `apiVersion`                           | `rbac.authorization.k8s.io/v1` | Yes      | `apiVersion: rbac.authorization.k8s.io/v1`                    |
| `metadata.name`                        | Computed name                  | Yes      | `name: my-custom-role-binding`                                |
| `metadata.labels`                      | Computed labels                | No       | `labels: {app: myapp, release: myrelease}`                    |
| `metadata.annotations`                 | Computed annotations           | No       | `annotations: {example: "This is an annotation"}`             |
| `metadata.namespace`                   | `.Release.namespace`           | No       | `namespace: custom-namespace`                                 |
| `roleRef.apiGroup`                     | `rbac.authorization.k8s.io`    | Yes      | `apiGroup: rbac.authorization.k8s.io`                         |
| `roleRef.kind`                         | Role or ClusterRole            | Yes      | Automatically determined by `clusterWideAccess`               |
| `roleRef.name`                         | Computed name                  | Yes      | `name: my-custom-role`                                        |
| `subjects`                             | None                           | Yes      | See subjects examples below                                   |
| `subjects[].kind`                      | `ServiceAccount`               | Yes      | `kind: ServiceAccount`                                        |
| `subjects[].name`                      | Computed service account name  | Yes      | `name: my-service-account`                                    |
| `subjects[].namespace`                 | `.Release.namespace`           | Yes      | `namespace: custom-namespace`                                 |

### Subjects Field Details

- **`subjects[].kind`**: Specifies the kind of subject (e.g., ServiceAccount).
- **`subjects[].name`**: Specifies the name of the subject. If not set, a default is computed based on the release and potential service account settings.
- **`subjects[].namespace`**: Specifies the namespace for the subject, defaults to the release's namespace if not explicitly set.

Each field helps define the RBAC binding configuration in Kubernetes, where you can specify detailed role bindings or cluster role bindings depending on the scope defined by `clusterWideAccess`. This template allows for granular control over RBAC settings to manage permissions effectively across your Kubernetes resources.

## Secret

| Field Name                                      | Default Value | Required | Example                                                       |
|-------------------------------------------------|---------------|----------|---------------------------------------------------------------|
| `fullnameOverride`                              | `nil`         | No       | `fullnameOverride: custom-secret`                             |
| `Release.Name`                                  | Provided by Helm at runtime | Yes | N/A                                                           |
| `Chart.Name`                                    | Provided by Helm at runtime | Yes | N/A                                                           |
| `Secret[*].name`                                | `nil`         | Yes      | `name: my-secret-name`                                        |
| `Secret[*].namespace`                           | `Release.Namespace` | No  | `namespace: my-custom-namespace`                              |
| `Secret[*].data`                                | `nil`         | No       | `data: { key: "filepath: configs/password.txt" }`             |
| `Secret[*].stringData`                          | `nil`         | No       | `stringData: { username: "admin" }`                           |
| `Secret[*].immutable`                           | `false`       | No       | `immutable: true`                                             |
| `Labels`                                        | Merged from `.Values.Secret` | No | `labels: { app: "my-app" }`                                 |
| `Annotations`                                   | Merged from `.Values.Secret` | No | `annotations: { description: "My custom secret" }`          |

### Notes:
- The fields are iterated over a map of secrets defined under `.Values.Secret` where each secret configuration allows customization.
- `fullnameOverride`, `Release.Name`, and `Chart.Name` are used to dynamically construct the secret name.
- Labels and annotations are merged from the secret-specific configuration and can include details like the application version or other metadata.
- `stringData` and `data` fields support direct values or fetching content from files, where file paths are automatically read and encoded if specified.
- The `immutable` field dictates whether the secret can be updated once created.

### Example Usage:

Given the following values:

```yaml
Secret:
  mySecret:
    namespace: my-namespace
    data:
      config.yaml:
        filepath: path/to/config.yaml
    stringData:
      username: admin
    immutable: true
```

## Service

| Field Name                                   | Default Value                  | Required | Example                                                      |
|----------------------------------------------|--------------------------------|----------|--------------------------------------------------------------|
| `Service.fullnameOverride`                   | None                           | No       | `fullnameOverride: custom-name`                              |
| `Service.releaseName`                        | `.Release.Name`                | Yes      | Automatically derived from Helm release                      |
| `Service.releaseNamespace`                   | `.Release.Namespace`           | Yes      | Automatically derived from Helm release                      |
| `Service.chartAppversion`                    | `.Chart.AppVersion`            | Yes      | Automatically derived from Helm chart                        |
| `Service.chartname`                          | `.Chart.Name`                  | Yes      | Automatically derived from Helm chart                        |
| `Service.selectorkind`                       | "Deployment"                   | No       | Automatically determined based on values.yaml                |
| `Service.metadata.name`                      | Computed name                  | Yes      | Concatenation of full name and service name                  |
| `Service.metadata.annotations`               | Computed                       | No       | Annotations defined in service config                        |
| `Service.metadata.labels`                    | Computed                       | No       | Labels defined in service config                             |
| `Service.metadata.namespace`                 | `.Release.Namespace`           | No       | `namespace: custom-namespace`                                |
| `Service.allocateLoadBalancerNodePorts`      | None                           | No       | `allocateLoadBalancerNodePorts: true`                        |
| `Service.clusterIP`                          | None                           | No       | `clusterIP: "None"`                                          |
| `Service.clusterIPs`                         | None                           | No       | `clusterIPs: ["10.96.0.1"]`                                  |
| `Service.externalIPs`                        | None                           | No       | `externalIPs: ["192.168.100.1"]`                             |
| `Service.externalName`                       | None                           | No       | `externalName: "my.external.example.com"`                    |
| `Service.externalTrafficPolicy`              | None                           | No       | `externalTrafficPolicy: Local`                               |
| `Service.healthCheckNodePort`                | None                           | No       | `healthCheckNodePort: 30012`                                 |
| `Service.internalTrafficPolicy`              | None                           | No       | `internalTrafficPolicy: Cluster`                             |
| `Service.ipFamilies`                         | None                           | No       | `ipFamilies: ["IPv4"]`                                       |
| `Service.ipFamilyPolicy`                     | None                           | No       | `ipFamilyPolicy: "RequireDualStack"`                         |
| `Service.loadBalancerClass`                  | None                           | No       | `loadBalancerClass: "external"`                              |
| `Service.loadBalancerIP`                     | None                           | No       | `loadBalancerIP: "192.168.100.1"`                            |
| `Service.loadBalancerSourceRanges`           | None                           | No       | `loadBalancerSourceRanges: ["192.168.0.0/16"]`               |
| `Service.ports`                              | None                           | Yes      | Detailed port configurations (See ports field details)       |
| `Service.publishNotReadyAddresses`           | `false`                        | No       | `publishNotReadyAddresses: true`                             |
| `Service.selector`                           | Computed                       | Yes      | Custom selectors or default derived from labels              |
| `Service.sessionAffinity`                    | None                           | No       | `sessionAffinity: "ClientIP"`                                |
| `Service.sessionAffinityConfig`              | None                           | No       | Custom session affinity configuration                        |
| `Service.trafficDistribution`                | None                           | No       | `trafficDistribution: "Cluster"`                             |
| `Service.type`                               | "ClusterIP"                    | No       | `type: "LoadBalancer"`                                       |



## Service Account

| Field Name                                       | Default Value | Required | Example                                                       |
|--------------------------------------------------|---------------|----------|---------------------------------------------------------------|
| `fullnameOverride`                               | `nil`         | No       | `fullnameOverride: custom-sa`                                 |
| `Release.Name`                                   | Set by Helm   | Yes      | N/A                                                           |
| `Chart.Name`                                     | Set by Helm   | Yes      | N/A                                                           |
| `ServiceAccount.namespace`                       | `.Release.Namespace` | No | `namespace: my-namespace`                                    |
| `ServiceAccount.secrets`                         | `nil`         | No       | `secrets: [{name: "my-secret"}]`                             |
| `ServiceAccount.automountServiceAccountToken`    | `true`        | No       | `automountServiceAccountToken: false`                         |
| `ServiceAccount.imagePullSecrets`                | `nil`         | No       | `imagePullSecrets: [{name: "my-docker-registry-secret"}]`    |
| `Labels`                                         | Merged from `.Values.ServiceAccount` | No | `labels: { app: "my-app" }`                                 |
| `Annotations`                                    | Merged from `.Values.ServiceAccount` | No | `annotations: { description: "My custom service account" }` |

### Notes:
- The `fullnameOverride`, `Release.Name`, and `Chart.Name` are used to dynamically construct the name of the service account.
- Labels and annotations can be customized per service account and are merged from `.Values.ServiceAccount`.
- The `secrets` field allows specifying which secrets can be accessed by pods running using this service account.
- The `automountServiceAccountToken` field determines whether a token, which facilitates API access, should be automatically mounted into pods.
- The `imagePullSecrets` field is used for specifying Docker registry credentials, which Kubernetes should use to pull images for the pods associated with this service account.

### Example Usage:
Given the following values in `values.yaml`:

```yaml
ServiceAccount:
  fullnameOverride: custom-sa
  automountServiceAccountToken: false
  secrets:
    - name: my-secret
  imagePullSecrets:
    - name: my-docker-registry-secret
```

## Configmap

| Field Name                                        | Default Value       | Required | Example                                                       |
|---------------------------------------------------|---------------------|----------|---------------------------------------------------------------|
| `fullnameOverride`                                | `nil`               | No       | `fullnameOverride: custom-cm`                                 |
| `Release.Name`                                    | Set by Helm         | Yes      | N/A                                                           |
| `Chart.Name`                                      | Set by Helm         | Yes      | N/A                                                           |
| `Configmap[*].name`                               | Derived from fullname template | Yes | `name: my-configmap-name`                                  |
| `Configmap[*].namespace`                          | `$releaseNamespace` | No       | `namespace: my-namespace`                                    |
| `Configmap[*].data`                               | `nil`               | No       | `data: { example: "This is a sample config data" }`           |
| `Configmap[*].binaryData`                         | `nil`               | No       | `binaryData: { file: "filepath: path/to/binary/data" }`       |
| `Configmap[*].immutable`                          | `false`             | No       | `immutable: true`                                            |
| `Labels`                                          | Merged from `.Values.Configmap` | No | `labels: { app: "my-app" }`                                 |
| `Annotations`                                     | Merged from `.Values.Configmap` | No | `annotations: { description: "Configuration for app" }`      |

### Notes:
- The `fullnameOverride`, `Release.Name`, and `Chart.Name` are used to construct the name of the config map dynamically.
- Labels and annotations can be customized per config map and are merged from `.Values.Configmap`.
- The `data` field allows for storing configuration parameters that will be consumed by applications running in the Kubernetes environment.
- The `binaryData` field supports binary data content, which is useful for storing data that cannot be represented in UTF-8 format.
- The `immutable` flag, when set to true, prevents changes to the ConfigMap once it is created, providing a level of assurance against accidental changes.

### Example Usage:
Given the following values in `values.yaml`:

```yaml
Configmap:
  appConfig:
    namespace: default
    data:
      app.properties: |
        app.name=MyApp
        app.timeout=100
    binaryData:
      logo.png:
        filepath: files/logo.png
    immutable: true

```




