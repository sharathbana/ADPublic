import json
import csv
import pandas as pd

# Paths for the input JSON, Parquet, and output CSV files
json_file_path = 'execution.json'
parquet_file_path = 'part-00000-c2262eb0-85f6-4767-ab37-3b494dbd87ba-c000.snappy.parquet'
output_csv_path = 'output.csv'

# Load JSON data
with open(json_file_path, 'r') as file:
    json_data = json.load(file)

# Load the Parquet file
parquet_data = pd.read_parquet(parquet_file_path)

# Define function to count occurrences of each status (0, 1, 2) in the specified column
def count_status(rule_column):
    if rule_column not in parquet_data.columns:
        return None, None, None  # Column not found in the Parquet file
    error_count = (parquet_data[rule_column] == 0).sum()
    success_count = (parquet_data[rule_column] == 1).sum()
    warning_count = (parquet_data[rule_column] == 2).sum()
    return error_count, success_count, warning_count

# Extract required fields from JSON and calculate counts for each rule
extracted_data = []
for item in json_data["body"]["analysisResults"]:
    rule_column = f"ad_rule__{item['ruleId']}__result"
    error_count, success_count, warning_count = count_status(rule_column)
    
    extracted_data.append({
        "column": item["column"],
        "ruleId": rule_column,
        "ruleType": item["ruleType"],
        "error_count": error_count,
        "success_count": success_count,
        "warning_count": warning_count
    })

# Write the extracted data to a CSV file
with open(output_csv_path, 'w', newline='') as csvfile:
    fieldnames = ["column", "ruleId", "ruleType", "error_count", "success_count", "warning_count"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    
    writer.writeheader()
    writer.writerows(extracted_data)

print(f"Data has been written to {output_csv_path}")
